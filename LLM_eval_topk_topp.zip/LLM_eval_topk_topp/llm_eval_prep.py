import json
import pandas as pd
import os
from pathlib import Path

def load_json_file(filepath):
    """Load and return JSON data from file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading {filepath}: {e}")
        return None

def extract_generated_text(entry):
    """Extract generated text, handling both 'generated_text' and 'generated_result' fields"""
    if 'generated_text' in entry:
        gen_data = entry['generated_text']
    elif 'generated_result' in entry:
        gen_data = entry['generated_result']
    else:
        return ""
    
    # Handle case where it's a dictionary with "0" key
    if isinstance(gen_data, dict) and "0" in gen_data:
        return gen_data["0"]
    elif isinstance(gen_data, str):
        return gen_data
    else:
        return str(gen_data)

def main():
    # Base directory
    base_dir = Path("C:/Users/esteb/Desktop/LLM_eval/")
    
    # File patterns
    datasets = ['wikitext', 'book', 'wikinews']
    methods = {
        'guard': 'guard_w_7',
        'topk': 'topk_k_50', 
        'topp': 'topp_p_095'
    }
    
    # Load all data
    all_data = {}
    
    for dataset in datasets:
        all_data[dataset] = {}
        for method_name, method_suffix in methods.items():
            filename = f"{dataset}_qwen2_{method_suffix}.json"
            filepath = base_dir / filename
            
            print(f"Loading {filename}...")
            data = load_json_file(filepath)
            
            if data is not None:
                all_data[dataset][method_name] = data
                print(f"  Loaded {len(data)} entries")
            else:
                print(f"  Failed to load {filename}")
    
    # Extract 20 stories (same indices across all datasets and methods)
    num_stories = 20
    comparison_data = []
    
    for dataset in datasets:
        if dataset not in all_data:
            continue
            
        # Get the minimum length across all methods for this dataset
        min_length = min(len(all_data[dataset][method]) 
                        for method in methods.keys() 
                        if method in all_data[dataset])
        
        if min_length < num_stories:
            print(f"Warning: {dataset} has only {min_length} entries, using all available")
            num_stories_dataset = min_length
        else:
            num_stories_dataset = num_stories
        
        # Create pairwise comparisons: GUARD vs top-k and GUARD vs top-p
        for comparison_method in ['topk', 'topp']:
            if 'guard' not in all_data[dataset] or comparison_method not in all_data[dataset]:
                print(f"Skipping {dataset} GUARD vs {comparison_method} - missing data")
                continue
                
            guard_data = all_data[dataset]['guard']
            comparison_data_method = all_data[dataset][comparison_method]
            
            for i in range(num_stories_dataset):
                # Extract data for both methods
                guard_entry = guard_data[i]
                comp_entry = comparison_data_method[i]
                
                # Get prompt (prefix_text)
                prompt = guard_entry.get('prefix_text', '')
                
                # Get generated texts
                guard_text = extract_generated_text(guard_entry)
                comp_text = extract_generated_text(comp_entry)
                
                # Get reference text if available
                reference = guard_entry.get('reference_text', '')
                
                # Add to comparison data
                comparison_data.append({
                    'dataset': dataset,
                    'comparison_type': f'guard_vs_{comparison_method}',
                    'story_index': i,
                    'prompt': prompt,
                    'reference_text': reference,
                    'method_a': 'guard',
                    'text_a': guard_text,
                    'method_b': comparison_method,
                    'text_b': comp_text
                })
    
    # Create DataFrame and save to CSV
    df = pd.DataFrame(comparison_data)
    
    # Save the results
    output_file = base_dir / "llm_evaluation_pairwise_comparisons.csv"
    df.to_csv(output_file, index=False, encoding='utf-8')
    
    print(f"\nSaved {len(df)} pairwise comparisons to {output_file}")
    print(f"\nDataset breakdown:")
    print(df['dataset'].value_counts())
    print(f"\nComparison type breakdown:")
    print(df['comparison_type'].value_counts())
    
    # Also save a summary
    summary_file = base_dir / "evaluation_summary.txt"
    with open(summary_file, 'w', encoding='utf-8') as f:
        f.write("LLM Evaluation Dataset Summary\n")
        f.write("=" * 40 + "\n\n")
        f.write(f"Total pairwise comparisons: {len(df)}\n\n")
        f.write("Dataset breakdown:\n")
        for dataset, count in df['dataset'].value_counts().items():
            f.write(f"  {dataset}: {count} comparisons\n")
        f.write("\nComparison type breakdown:\n")
        for comp_type, count in df['comparison_type'].value_counts().items():
            f.write(f"  {comp_type}: {count} comparisons\n")
        f.write(f"\nFiles processed:\n")
        for dataset in datasets:
            for method_name, method_suffix in methods.items():
                filename = f"{dataset}_qwen2_{method_suffix}.json"
                f.write(f"  {filename}\n")
    
    print(f"Summary saved to {summary_file}")
    
    # Display first few rows as preview
    print(f"\nPreview of first 3 rows:")
    print(df[['dataset', 'comparison_type', 'story_index', 'method_a', 'method_b']].head(3))

if __name__ == "__main__":
    main()